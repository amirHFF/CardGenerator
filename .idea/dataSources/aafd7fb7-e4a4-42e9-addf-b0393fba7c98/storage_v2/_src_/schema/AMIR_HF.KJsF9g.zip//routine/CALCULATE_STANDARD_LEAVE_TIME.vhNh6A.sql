create function calculate_standard_Leave_Time(leaveTime in varchar2,is_daily in NUMBER)
return number
is

standard_time varchar2(5) :='8:30';
milisec_standard_time number :=0;
hour varchar2(5) :=0;

begin
    if is_daily=1 then
        select instr(standard_time,':') into hour from dual;

        if hour = 0 then 
            milisec_standard_time := to_number(standard_time) * 3600000;
        end if;
        if hour > 0 then 
            milisec_standard_time := to_number(substr( standard_time , instr(standard_time , ':' )+1))*60000;
            milisec_standard_time := milisec_standard_time + to_number(substr( standard_time , 0 , instr(standard_time , ':')-1))* 3600000;
        end if;
        return milisec_standard_time;
    end if;
    if  is_daily=0 then
        return leaveTime;
        end if;


end;
/

