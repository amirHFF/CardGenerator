create function FN_EMS_STANDARD_LEAVETIME_CALCULATOR(leaveTime in varchar2,LEAVEDATE in timestamp ,LABOR_REGISTRAR in number )
return number
is
standard_time NVARCHAR2(5):='10';
milisec_standard_time number :=0;
hour varchar2(250) :=0;
IS_DAILY NUMBER :=null;

begin
--    SELECT c_value INTO standard_time FROM T_TAM_CONFIGURATION WHERE C_CODE='DailyLeaveRequestCalculationValue';
--    select LR.C_IS_DAILY INTO IS_DAILY FROM T_TAM_LEAVE_REQUEST LR WHERE LEAVEDATE
--    BETWEEN LR.C_START_DATE AND LR.C_END_DATE AND LR.C_VR_LABOR_REGISTRAR=LABOR_REGISTRAR and ROWNUM = 1;
    if is_daily=1 AND leaveTime>0 then
        select instr(standard_time,':') into hour from dual;

        if to_number(hour) = 0 then
            milisec_standard_time := to_number(standard_time) * 3600000;
        end if;
        if to_number(hour) > 0 then
            milisec_standard_time := to_number(substr( standard_time , instr(standard_time , ':' )+1))*60000;
            milisec_standard_time := milisec_standard_time + to_number(substr( standard_time , 0 , instr(standard_time , ':')-1))* 3600000;
        end if;
        return milisec_standard_time;
    end if;

    if  is_daily=0 OR leaveTime=0 then
        return leaveTime;
    else
        return 0;
    end if;


end;
/

