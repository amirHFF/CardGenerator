create function FN_EMS_TIME_TO_MILISEC(LEAVE IN VARCHAR2)
RETURN number
IS RESULT  VARCHAR2(20);
BEGIN
    IF INSTR(LEAVE,':')>0 THEN
        RESULT := SUBSTR(LEAVE,0,instr(LEAVE,':')-1)*3600000 + SUBSTR(LEAVE,instr(LEAVE,':')+1)*60000 ;
        end if;
    IF INSTR(LEAVE,':')=0 THEN
        RESULT := LEAVE*3600000 ;
    END IF;
    return result;
END;
/

