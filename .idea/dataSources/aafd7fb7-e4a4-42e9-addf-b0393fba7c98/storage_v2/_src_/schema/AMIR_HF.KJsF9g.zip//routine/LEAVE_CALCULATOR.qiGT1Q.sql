create FUNCTION LEAVE_CALCULATOR(LEAVE IN NUMBER , OUTPUT_TYPE IN NUMBER)
  RETURN VARCHAR2
  IS
    DAY NUMBER :=0;
    HOUR NUMBER :=0;
    MINUTES NUMBER :=0;
    LEAVE_TYPE number:=1;
    HOURS_OF_DAY NUMBER:=8;
    RES VARCHAR2(40);
  BEGIN
--    SELECT c_value INTO LEAVE_TYPE FROM t_tam_configuration WHERE C_CODE='DailyLeaveRequestCalculationMethod';
--    SELECT c_value INTO LEAVE_TYPE FROM HOURS_OF_DAY WHERE C_CODE='DailyLeaveRequestCalculationValue';


          IF (LEAVE/3600000)/HOURS_OF_DAY>1 THEN 
                DAY :=TRUNC((LEAVE/3600000)/HOURS_OF_DAY);
                HOUR := TRUNC(mod((LEAVE/3600000),HOURS_OF_DAY));
                MINUTES := TRUNC(mod(LEAVE,3600000)/60000);

            ELSE 
              HOUR := TRUNC(LEAVE/3600000);
              MINUTES := TRUNC(mod(LEAVE,3600000)/60000);
          END IF;


       RES := CONCAT(CONCAT(CONCAT(CONCAT(DAY,':'),HOUR),':'),MINUTES);


        IF OUTPUT_TYPE=0 THEN
            return res;
            END IF;
        IF OUTPUT_TYPE=1 THEN 
            RES :=CONCAT(CONCAT(HOUR,':'),MINUTES);
            RETURN RES;
            END IF;
        IF OUTPUT_TYPE=2 THEN 
            RETURN DAY;
            END IF;
  END;
/

